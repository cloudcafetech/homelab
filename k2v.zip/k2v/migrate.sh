#!/bin/bash
# VM Migration Script Kubevirt to VMware
# Developed by CloudCafeTech [ cloudcafetech@gmail.com ]
# Own by Prasenjit Kar
set -e
# =========================================================================
# --- NON-ROOT PRIVILEGE CORRECTION LAYER ---
# Redirects all systemic tool tracking profiles (.govmomi, .kube, .config)
# into the universally writeable /tmp partition for standard compliance.
# =========================================================================
export HOME="/tmp"
export GOVC_HOME="/tmp"

# Establish writeable directory target paths within /tmp for safe processing
mkdir -p /tmp/run-workspace
cd /tmp/run-workspace

# Configurations passed via Env vars
VC_URL="${VCENTER_HOST}"
VM_NAME=$(echo "${VW_VM_NAME}" | tr -s ' ' '-')
EXPORT_DIR="/mnt/export"
PASSWORD_FILE=$(mktemp)
echo ${ESXI_PASS} > "$PASSWORD_FILE"
chmod 0600 "$PASSWORD_FILE"
VC_USER='administrator%40vsphere.local'   # DO NOT MODIFY WITH ORIGINAL
export GOVC_URL="https://${ESXI_USER}:${ESXI_PASS}@${VC_URL}/sdk"
export GOVC_INSECURE=true
export LIBGUESTFS_BACKEND=direct
export LIBGUESTFS_CACHEDIR="/tmp/.guestfs-cache"
mkdir -p "$LIBGUESTFS_CACHEDIR"

# Debug
#sleep 3000
# =========================================================================
# Capture VM Metadata and OS Type Detection
# =========================================================================
discover_vm() {
    echo "===> Discovering VM specs for [ ${KV_VM_NAME} ]..."
    
    if ! oc get vm "${KV_VM_NAME}" -n "${NAMESPACE}" &>/dev/null; then
        echo "ERROR: Source VM '${KV_VM_NAME}' not found in namespace '${NAMESPACE}'!"
        exit 1
    fi

    VM_CPUS=$(oc get vm "${KV_VM_NAME}" -n "${NAMESPACE}" -o jsonpath='{.spec.template.spec.domain.cpu.cores}' 2>/dev/null || echo "4")
    [ -z "$VM_CPUS" ] && VM_CPUS="4"
    
    RAW_MEM=$(oc get vm "${KV_VM_NAME}" -n "${NAMESPACE}" -o jsonpath='{.spec.template.spec.domain.resources.requests.memory}' 2>/dev/null || echo "8Gi")
    
    if [[ "$RAW_MEM" == *Gi ]]; then
        NUM=$(echo "$RAW_MEM" | sed 's/Gi//')
        VM_MEM=$((NUM * 1024))
    elif [[ "$RAW_MEM" == *Mi ]]; then
        VM_MEM=$(echo "$RAW_MEM" | sed 's/Mi//')
    else
        VM_MEM="8192"
    fi

    echo "Capturing active IP addresses..."
    VM_IPS=$(oc get vmi "${KV_VM_NAME}" -n "${NAMESPACE}" -o jsonpath='{.status.interfaces[*].ipAddress}' 2>/dev/null || echo "Unknown/Not Running")

    echo "Capturing Firmware..."
    VM_FIRM=$(oc describe vm "${KV_VM_NAME}" -n "${NAMESPACE}" | grep -i efi)
    if [[ "$VM_FIRM" == "" ]]; then
        DYNAMIC_FIRMWARE="bios"
    else
        DYNAMIC_FIRMWARE="efi"
    fi


    echo "Detecting Guest Operating System profile..."
    #VM_OS_INFO=$(oc get vm "${KV_VM_NAME}" -n "${NAMESPACE}" -o json | tr '[:upper:]' '[:lower:]')
    
    if [[ "$VM_OS_TYPE" == *"win"* ]]; then
        DETECTED_OS="Windows"
        DYNAMIC_GUEST_ID="windows2019srv_64Guest"
        DYNAMIC_CONTROLLER="lsilogicsas"
    elif [[ "$VM_OS_TYPE" == *"rhel"* ]]; then
        DETECTED_OS="RedHatLinux"
        DYNAMIC_GUEST_ID="rhel8_64Guest"
        DYNAMIC_CONTROLLER="pvscsi"
    elif [[ "$VM_OS_TYPE" == *"cent"* ]]; then
        DETECTED_OS="CentOS"
        DYNAMIC_GUEST_ID="centos7_64Guest"
        DYNAMIC_CONTROLLER="pvscsi"
    else 
        DETECTED_OS="Linux"
        DYNAMIC_GUEST_ID="ubuntu64Guest"
        DYNAMIC_CONTROLLER="pvscsi"       
    fi

    METADATA_FILE="$EXPORT_DIR/${KV_VM_NAME}_info.txt"
    echo "==========================================" > "$METADATA_FILE"
    echo "           VM MIGRATION METADATA          " >> "$METADATA_FILE"
    echo "==========================================" >> "$METADATA_FILE"
    echo "Source VM Name : ${KV_VM_NAME}" >> "$METADATA_FILE"
    echo "Namespace      : ${NAMESPACE}" >> "$METADATA_FILE"
    echo "Detected OS    : ${DETECTED_OS}" >> "$METADATA_FILE"
    echo "vCPUs Allocated: ${VM_CPUS}" >> "$METADATA_FILE"
    echo "Memory Size    : ${RAW_MEM} (${VM_MEM} MB)" >> "$METADATA_FILE"
    echo "Captured IPs   : ${VM_IPS}" >> "$METADATA_FILE"
    echo "Migration Date : $(date)" >> "$METADATA_FILE"
    echo "==========================================" >> "$METADATA_FILE"

    echo "--- Discovered Specs Captured & Saved to PVC ---"
    cat "$METADATA_FILE"
    echo "------------------------------------------------"
}


# =========================================================================
# Stop VM
# =========================================================================
stop_vm() {
    echo "===> Checking current status of VM [ ${KV_VM_NAME} ]..."
    INITIAL_STATUS=$(oc get vm ${KV_VM_NAME} -n ${NAMESPACE} -o jsonpath='{.status.printableStatus}' 2>/dev/null || echo "Unknown")
    
    if [ "${INITIAL_STATUS}" = "Stopped" ]; then
        echo "VM [ ${KV_VM_NAME} ] is already stopped. Proceeding to next step."
        return 0
    fi

    echo "===> Stopping VM [ ${KV_VM_NAME} ] ..."
    # The '|| true' ensures that if it's already in the process of stopping, it won't crash the script
    virtctl stop ${KV_VM_NAME} -n ${NAMESPACE} || true
    #oc patch vm ${KV_VM_NAME} -n ${NAMESPACE} --type merge -p '{"spec":{"running":false}}'

    while true; do
      STATUS=$(oc get vm ${KV_VM_NAME} -n ${NAMESPACE} -o jsonpath='{.status.printableStatus}' 2>/dev/null || echo "Unknown")
      if [ "${STATUS}" = "Stopped" ]; then
         echo "VM [ ${KV_VM_NAME} ] is verified stopped."
         break
      fi
      echo "Current status: ${STATUS}. Waiting 5s..."
      sleep 5
    done
}

# =========================================================================
# Export Image
# =========================================================================
export_vm() {
    echo "===> Triggering VM Export ..."
    EXPORT_NAME="${KV_VM_NAME}-export"

    # Cleanup older export iteration CRDs if they exist to prevent name conflicts
    if oc get vmexport "${EXPORT_NAME}" -n "${NAMESPACE}" &>/dev/null; then
        echo "Old export resource found, cleaning up..."
        oc delete vmexport "${EXPORT_NAME}" -n "${NAMESPACE}" --wait=true || true
        sleep 20
    fi

    # Declaratively maps the export to utilize your pre-created PVC
    cat <<EOF | oc apply -f -
apiVersion: export.kubevirt.io/v1beta1
kind: VirtualMachineExport
metadata:
  name: "${EXPORT_NAME}"
  namespace: "${NAMESPACE}"
spec:
  source:
    apiGroup: "kubevirt.io"
    kind: VirtualMachine
    name: "${KV_VM_NAME}"
  pvc:
    claimName: "${PVC_NAME}"
EOF

    echo "Waiting for VM Export processing to complete..."
    while true; do
      PHASE=$(oc get vmexport "${EXPORT_NAME}" -n "${NAMESPACE}" -o jsonpath='{.status.phase}' 2>/dev/null || echo "Unknown")
      echo "Exporting state: ${PHASE}"
       if [ "${PHASE}" = "Ready" ]; then 
         echo "Export completely finished and verified."
         break
       fi
       if [ "${PHASE}" = "Failed" ]; then 
         echo "ERROR: Declarative VM export processing failed!"
         exit 1; 
       fi
       sleep 5
    done
    sleep 10
}

# =========================================================================
# Download Image
# =========================================================================
download() {
    EXPORT_NAME="${KV_VM_NAME}-export"
    echo "===> Streaming Exported Disks via Internal Cluster Network..."

    if [ -d "$EXPORT_DIR/volumes" ]; then
        echo "Cleaning up old volume layouts..."
        rm -rf "$EXPORT_DIR/volumes"
        sleep 5
    fi
    mkdir -p "$EXPORT_DIR/volumes"

    # 1. Fetch VM export status details
    VM_EXPORT_JSON=$(oc get vmexport "${EXPORT_NAME}" -n "${NAMESPACE}" -o json)

    SECRET_NAME=$(echo "$VM_EXPORT_JSON" | jq -r '.status.tokenSecretRef')
    EXPORT_TOKEN=$(oc get secret "${SECRET_NAME}" -n "${NAMESPACE}" -o jsonpath='{.data.token}' | base64 -d)
    SERVICE_NAME=$(echo "$VM_EXPORT_JSON" | jq -r '.status.serviceName')
    VOLUMES=$(echo "$VM_EXPORT_JSON" | jq -r '.status.links.internal.volumes[].name')

    # 2. Discover the service ClusterIP to bypass DNS issues
    echo "Discovering ClusterIP for service: ${SERVICE_NAME} in namespace: ${NAMESPACE}..."
    SERVICE_IP=$(oc get svc "${SERVICE_NAME}" -n "${NAMESPACE}" -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo "")

    if [ -z "${SERVICE_IP}" ] || [ "${SERVICE_IP}" = "None" ]; then
        echo "ERROR: Could not retrieve a valid ClusterIP for service ${SERVICE_NAME}!"
        exit 1
    fi
    echo "Successfully locked Service IP: ${SERVICE_IP}"

    for vol in ${VOLUMES}; do
        echo "Directly streaming internal volume: ${vol}"
        mkdir -p "$EXPORT_DIR/volumes/${vol}"

        # 3. CRITICAL FIX: SELECT EXACTLY ONE LINK FORMAT (PREFERS GZIP ARCHIVE)
        # This searches the formats array, targets 'gzip' first, and drops back to 'raw' if gzip is missing, 
        # ensuring exactly 1 URL string line is generated.
        INTERNAL_URL=$(echo "$VM_EXPORT_JSON" | jq -r --arg VOL "$vol" '
            .status.links.internal.volumes[] | select(.name == $VOL) | .formats | 
            (select(.[] | .format == "gzip") | .[] | select(.format == "gzip") | .url) // 
            (select(.[] | .format == "raw") | .[] | select(.format == "raw") | .url)
        ' | head -n 1)

        # Ensure we are tracking a clean domain layout for curl's host matching rules
        if [[ "$INTERNAL_URL" == *".svc/volumes"* ]]; then
            INTERNAL_URL=$(echo "$INTERNAL_URL" | sed 's/\.svc\/volumes/\.svc\.cluster\.local:443\/volumes/g')
        fi

        # Parse out the bare hostname to supply to curl's router engine
        DOMAIN_HOST=$(echo "${INTERNAL_URL}" | awk -F/ '{print $3}' | cut -d: -f1)
        FILENAME=$(basename "${INTERNAL_URL}")
        OUT_FILE="$EXPORT_DIR/volumes/${vol}/${FILENAME}"

        echo "Targeting system resource: ${FILENAME}"
        echo "Targeting internal stream URL: ${INTERNAL_URL}"
        echo "Directing traffic over IP Route: ${DOMAIN_HOST}:443 -> ${SERVICE_IP}"

        # 4. EXECUTE CURL DOWNLOAD ROUTINES BYPASSING DNS ENTIRELY VIA --resolve
        echo "Checking Method 1 (x-kubevirt-export-token)..."
        HTTP_STATUS=$(curl -kL -s -o /dev/null -w "%{http_code}" --connect-timeout 15 \
          --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
          -H "x-kubevirt-export-token: ${EXPORT_TOKEN}" "${INTERNAL_URL}")
        
        if [ "$HTTP_STATUS" = "200" ]; then
            curl -kL -# --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
              -H "x-kubevirt-export-token: ${EXPORT_TOKEN}" "${INTERNAL_URL}" -o "${OUT_FILE}"
            continue
        fi

        echo "Checking Method 2 (Authorization Bearer)..."
        HTTP_STATUS=$(curl -kL -s -o /dev/null -w "%{http_code}" --connect-timeout 15 \
          --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
          -H "Authorization: Bearer ${EXPORT_TOKEN}" "${INTERNAL_URL}")
        
        if [ "$HTTP_STATUS" = "200" ]; then
            curl -kL -# --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
              -H "Authorization: Bearer ${EXPORT_TOKEN}" "${INTERNAL_URL}" -o "${OUT_FILE}"
            continue
        fi

        echo "Checking Method 3 (Cookie auth_token)..."
        HTTP_STATUS=$(curl -kL -s -o /dev/null -w "%{http_code}" --connect-timeout 15 \
          --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
          -H "Cookie: auth_token=${EXPORT_TOKEN}" "${INTERNAL_URL}")
        
        if [ "$HTTP_STATUS" = "200" ]; then
            curl -kL -# --resolve "${DOMAIN_HOST}:443:${SERVICE_IP}" \
              -H "Cookie: auth_token=${EXPORT_TOKEN}" "${INTERNAL_URL}" -o "${OUT_FILE}"
            continue
        fi

        echo "Error: Failed to download volume ${vol} via all methods. (HTTP Status Checked: ${HTTP_STATUS})"
        exit 1
    done
}

# =========================================================================
# Unpack VM Archives
# =========================================================================
unpack_vm() {
    echo "===> Unpacking Multi-Disk VM Archives..."
    echo "Checking for compressed gzip disk archives..."
    GZ_FILES=$(find "$EXPORT_DIR/volumes" -type f -name "*.gz")

    for gz_file in ${GZ_FILES}; do
        echo "Decompressing archive: ${gz_file}..."
        gunzip -f "${gz_file}"
    done
}

# =========================================================================
# Assign IP using DHCP 
# =========================================================================
assign_ip_dhcp() {
    echo "===> Resetting Network Interfaces to DHCP  ..."

    # Locate all ready uncompressed disk images within the volume workspace
    DISK_PATHS=$(find "$EXPORT_DIR/volumes" -type f \( -name "disk.img" -o -name "disk.qcow2" -o -name "disk.raw" \))

    if [ -z "${DISK_PATHS}" ]; then
        echo "ERROR: No disk images found to reset network configurations!"
        exit 1
    fi

    for src in ${DISK_PATHS}; do
        vol_name=$(basename "$(dirname "${src}")")
        
        # 1. INTERNALLY CHECK IF THIS SPECIFIC DISK CONTAINS AN OPERATING SYSTEM
        IS_BOOT_DISK=false
        if virt-inspector -a "${src}" --xpath "count(/root)" &>/dev/null; then
            OS_COUNT=$(virt-inspector -a "${src}" --xpath "count(/root)" 2>/dev/null || echo "0")
            if [ "$OS_COUNT" != "0" ]; then
                IS_BOOT_DISK=true
            fi
        else
            # Fallback rule if virt-inspector xpath check is restricted
            if [[ "${vol_name}" == *"sda"* ]] || [[ "${vol_name}" == *"root"* ]]; then
                IS_BOOT_DISK=true
            fi
        fi

        # 2. RUN IN-PLACE CONFIGURATION MODIFICATIONS ONLY ON THE BOOT DISK
        if [ "$IS_BOOT_DISK" = "true" ]; then
            echo "=> Boot disk found at [ ${vol_name} ]. Enforcing DHCP network alignment profile..."

            if [[ "${VM_OS_TYPE}" == *"rhel"* ]] || [[ "${VM_OS_TYPE}" == *"cent"* ]]; then
                echo "Reconfiguring existing Red Hat/CentOS NetworkManager profile to DHCP..."
                virt-customize -a "${src}" --run-command "
                    NM_FILE=\$(find /etc/NetworkManager/system-connections/ -type f -name '*.nmconnection' | head -n 1)
                    if [ -n \"\$NM_FILE\" ]; then
                        echo \"Modifying NetworkManager keyfile: \$NM_FILE\"
                        sed -i '/\[ipv4\]/,/^$/{s/method=.*/method=auto/}' \"\$NM_FILE\"
                        sed -i '/^address1=/d' \"\$NM_FILE\"
                        sed -i '/^dns=/d' \"\$NM_FILE\"
                        sed -i 's/^interface-name=.*/interface-name=*/g' \"\$NM_FILE\"
                        chmod 0600 \"\$NM_FILE\"
                    else
                        echo \"WARNING: No pre-existing nmconnection profiles discovered to modify!\"
                    fi
                "

            elif [[ "${VM_OS_TYPE}" == *"ubu"* ]]; then
                echo "Reconfiguring existing Ubuntu Netplan definition tracks to DHCP..."
                virt-customize -a "${src}" --run-command "
                    NETPLAN_FILE=\$(find /etc/netplan/ -type f -name '*.yaml' | head -n 1)
                    if [ -n \"\$NETPLAN_FILE\" ]; then
                        echo \"Overwriting Netplan profile config for DHCP: \$NETPLAN_FILE\"
                        echo -e \"network:\\n  version: 2\\n  renderer: networkd\\n  ethernets:\\n    en_migration:\\n      match:\\n        name: \\\"en*\\\"\\n      dhcp4: true\" > \"\$NETPLAN_FILE\"
                        chmod 0600 \"\$NETPLAN_FILE\"
                    fi
                "

            elif [[ "${VM_OS_TYPE}" == *"win"* ]]; then
                echo "Injecting first-boot adaptation routine to enforce DHCP inside Windows..."
                virt-customize -a "${src}" --write "/ProgramData/Microsoft/Windows/Start Menu/Programs/StartUp/set_ip.bat:
@echo off
for /f \"tokens=3*\" %%i in ('netsh interface show interface ^| findstr \"Connected\"') do set \"interface_name=%%j\"
if \"%interface_name%\"==\"\" set \"interface_name=Ethernet\"
netsh interface ipv4 set address name=\"%interface_name%\" source=dhcp >nul 2>&1
netsh interface ipv4 set dns name=\"%interface_name%\" source=dhcp >nul 2>&1
del \"%~f0\""
            fi
            
            break
        fi
    done
}

# =========================================================================
# Assign Static IP
# =========================================================================
assign_ip_static() {
    echo "===> Injecting Network Configurations via virt-customize ..."
    # Track targets passing down from script/pipeline environment variables
    TARGET_IP="${VM_IPS}"
    TARGET_PREFIX="${VM_NETMASK}"
    TARGET_NM="${VM_NETMASK1}"
    TARGET_GW="${VM_GATEWAY}"
    TARGET_DNS="${VM_DNS}"

    # If no IP is provided in the environment, skip the function gracefully
    if [ -z "${TARGET_IP}" ]; then
        echo "No ${VM_IPS} detected in environment. Skipping network injection layer."
        return 0
    fi

    # Locate all ready uncompressed disk images within the volume workspace
    DISK_PATHS=$(find "$EXPORT_DIR/volumes" -type f \( -name "disk.img" -o -name "disk.qcow2" -o -name "disk.raw" \))

    if [ -z "${DISK_PATHS}" ]; then
        echo "ERROR: No disk images found to inject IP configuration into!"
        exit 1
    fi

    for src in ${DISK_PATHS}; do
        vol_name=$(basename "$(dirname "${src}")")
        
        # 1. INTERNALLY CHECK IF THIS SPECIFIC DISK CONTAINS AN OPERATING SYSTEM
        IS_BOOT_DISK=false
        if virt-inspector -a "${src}" --xpath "count(/root)" &>/dev/null; then
            OS_COUNT=$(virt-inspector -a "${src}" --xpath "count(/root)" 2>/dev/null || echo "0")
            if [ "$OS_COUNT" != "0" ]; then
                IS_BOOT_DISK=true
            fi
        else
            # Fallback rule if virt-inspector xpath check is restricted
            if [[ "${vol_name}" == *"sda"* ]] || [[ "${vol_name}" == *"root"* ]]; then
                IS_BOOT_DISK=true
            fi
        fi

        # 2. RUN IN-PLACE CONFIGURATION MODIFICATIONS ONLY ON THE BOOT DISK
        if [ "$IS_BOOT_DISK" = "true" ]; then
            echo "=> Boot disk found at [ ${vol_name} ]. Injecting IP profile: ${TARGET_IP}/${TARGET_PREFIX}"

            if [[ "${VM_OS_TYPE}" == *"rhel"* ]] || [[ "${VM_OS_TYPE}" == *"cent"* ]]; then
                echo "Updating existing Red Hat/CentOS NetworkManager profile in-place..."
                virt-customize -a "${src}" --run-command "
                    NM_FILE=\$(find /etc/NetworkManager/system-connections/ -type f -name '*.nmconnection' | head -n 1)
                    if [ -n \"\$NM_FILE\" ]; then
                        echo \"Modifying NetworkManager keyfile: \$NM_FILE\"
                        sed -i '/\[ipv4\]/,/^$/{s/method=.*/method=manual/}' \"\$NM_FILE\"
                        sed -i '/^address1=/d' \"\$NM_FILE\"
                        sed -i '/^dns=/d' \"\$NM_FILE\"
                        sed -i \"/\[ipv4\]/a address1=${TARGET_IP}/${TARGET_PREFIX},\\ngateway=${TARGET_GW}\\ndns=${TARGET_DNS};\" \"\$NM_FILE\"
                        sed -i 's/^interface-name=.*/interface-name=*/g' \"\$NM_FILE\"
                        chmod 0600 \"\$NM_FILE\"
                    else
                        echo \"WARNING: No pre-existing nmconnection profiles discovered to modify!\"
                    fi
                "

            elif [[ "${VM_OS_TYPE}" == *"ubu"* ]]; then
                echo "Updating existing Ubuntu Netplan definition tracks..."
                virt-customize -a "${src}" --run-command "
                    NETPLAN_FILE=\$(find /etc/netplan/ -type f -name '*.yaml' | head -n 1)
                    if [ -n \"\$NETPLAN_FILE\" ]; then
                        echo \"Overwriting Netplan profile config: \$NETPLAN_FILE\"
                        echo -e \"network:\\n  version: 2\\n  renderer: networkd\\n  ethernets:\\n    en_migration:\\n      match:\\n        name: \\\"en*\\\"\\n      addresses:\\n        - ${TARGET_IP}/${TARGET_PREFIX}\\n      routes:\\n        - to: default\\n          via: ${TARGET_GW}\\n      nameservers:\\n        addresses: [${TARGET_DNS}]\" > \"\$NETPLAN_FILE\"
                        chmod 0600 \"\$NETPLAN_FILE\"
                    fi
                "

            elif [[ "${VM_OS_TYPE}" == *"win"* ]]; then
                echo "Injecting first-boot adaptation routine to refresh network interfaces inside Windows..."
                virt-customize -a "${src}" --write "/ProgramData/Microsoft/Windows/Start Menu/Programs/StartUp/set_ip.bat:
    @echo off
    for /f \"tokens=3*\" %%i in ('netsh interface show interface ^| findstr \"Connected\"') do set \"interface_name=%%j\"
    if \"%interface_name%\"==\"\" set \"interface_name=Ethernet\"
    netsh interface ipv4 set address name=\"%interface_name%\" dhcp >nul 2>&1
    netsh interface ipv4 set address name=\"%interface_name%\" static ${TARGET_IP} ${TARGET_NM} ${TARGET_GW}
    netsh interface ipv4 set dns name=\"%interface_name%\" static ${TARGET_DNS} primary
    del \"%~f0\""
            fi
            
            # Network injection complete for the boot drive; break out of the disk loop safely
            break
        fi
    done
}

# =========================================================================
# Convert to VMDK
# =========================================================================
convert_vmdk() {
    echo "===> Converting Images to VMDK..."
    DISK_PATHS=$(find "$EXPORT_DIR/volumes" -type f \( -name "disk.img" -o -name "disk.qcow2" -o -name "disk.raw" \))

    if [ -z "${DISK_PATHS}" ]; then
        echo "ERROR: No compatible disk images found to convert to VMDK!"
        exit 1
    fi

    for src in ${DISK_PATHS}; do
        vol_name=$(basename "$(dirname "${src}")")
        filename=$(basename "${src}")
        
        # Run driver modifications immediately before compression
        if [ "${IS_BOOT_DISK}" = "true" ] || [[ "${vol_name}" == *"sda"* ]] || [[ "${vol_name}" == *"root"* ]]; then
            echo "Applying Guest OS storage driver fixes onto boot drive: ${vol_name}..."
            if [[ "${VM_OS_TYPE}" == *"rhel"* ]] || [[ "${VM_OS_TYPE}" == *"cent"* ]]; then
                virt-customize -a "${src}" --run-command "dracut --regenerate-all --force --add-drivers 'mptbase mptscsih mptsas vmw_pvscsi nvme ahci'"
            elif [[ "${VM_OS_TYPE}" == *"ubu"* ]]; then
                virt-customize -a "${src}" --run-command "sed -i 's/MODULES=dep/MODULES=most/g' /etc/initramfs-tools/initramfs.conf && update-initramfs -u -k all"
            elif [[ "${VM_OS_TYPE}" == *"win"* ]]; then
                virt-v2v -i disk "${src}" -o qemu -of qcow2 -os "$EXPORT_DIR" || true
                V2V_WIN_OUT=$(find "$EXPORT_DIR" -maxdepth 1 -type f -name "*-sda" -o -name "*.qcow2" | head -n 1)
                if [ -n "${V2V_WIN_OUT}" ]; then mv "${V2V_WIN_OUT}" "${src}"; fi
            fi
        fi

        echo "Converting processed image ${filename} to streamOptimized VMDK..."
        qemu-img convert -p -O vmdk -o subformat=streamOptimized "${src}" "$EXPORT_DIR/${vol_name}-stream.vmdk"
        echo ""

        echo "Verifying volume [ ${vol_name}-stream.vmdk ] structure..."
        qemu-img info "$EXPORT_DIR/${vol_name}-stream.vmdk"
        
        # Reclaim workspace storage space safely after VMDK generation completes
        rm -f "${src}"
    done
}

# =========================================================================
# Upload to VMware 
# =========================================================================
upload() {
    echo "===> Uploading VMDK to VMware ..."
    
    # Pre-create the directory once to prevent 500 errors on subsequent uploads
    govc datastore.mkdir "${VM_NAME}" 2>/dev/null || true
    
    # Track disk count index to keep disk names clean (e.g., _0.vmdk, _1.vmdk)
    local disk_index=0

    for stream_vmdk in "$EXPORT_DIR"/*-stream.vmdk; do
      [ -e "${stream_vmdk}" ] || continue
      
      vmdk_filename=$(basename "${stream_vmdk}")
      
      local target_vmdk_path="${VM_NAME}/${VM_NAME}_${disk_index}_stream.vmdk"
      
      echo "Streaming raw ${vmdk_filename} to unique datastore path: ${target_vmdk_path}"
      govc import.vmdk -force=true "${stream_vmdk}" "${target_vmdk_path}"
      echo ""
      
      disk_index=$((disk_index + 1))
    done
}

# =========================================================================
# Provision VM (FIXED: Attaches unique multi-disk tracks in correct order)
# =========================================================================
provision_vm() {
    echo "===> Provisioning VMware VM..."

    # Automatically clean up stale inventory conflicts if they exist
    if govc vm.info "${VM_NAME}" &>/dev/null; then
        echo "Warning: Stale VM wrapper '${VM_NAME}' detected. Overwriting inventory context..."
        govc vm.destroy "${VM_NAME}" || true
        sleep 5
    fi

    echo "Creating virtual architecture wrapper for: ${VM_NAME} (GuestOS: ${DYNAMIC_GUEST_ID}, Contr: ${DYNAMIC_CONTROLLER} Firm: ${DYNAMIC_FIRMWARE})"
    govc vm.create \
     -m "${VM_MEM}" \
     -c "${VM_CPUS}" \
     -net "${VM_NET}" \
     -g "${DYNAMIC_GUEST_ID}" \
     -firmware "${DYNAMIC_FIRMWARE}" \
     -disk.controller "${DYNAMIC_CONTROLLER}" \
     -on=false \
     "${VM_NAME}"

    echo "Inflating streamed disks and attaching in sequential boot order..."
    local disk_index=0
    for stream_vmdk in "$EXPORT_DIR"/*-stream.vmdk; do
      [ -e "${stream_vmdk}" ] || continue
      
      local source_stream_path="${VM_NAME}/${VM_NAME}_${disk_index}_stream.vmdk"
      local final_thin_path="${VM_NAME}/${VM_NAME}_${disk_index}.vmdk"
      
      echo "Inflating streamed disk [ ${source_stream_path} ] to bootable format [ ${final_thin_path} ]..."
      govc datastore.cp -f=true "${source_stream_path}" "${final_thin_path}"
      
      echo "Cleaning up transient upload stream archive..."
      govc datastore.rm -f "${source_stream_path}" || true

      echo "Attaching usable disk index [ ${disk_index} ] from datastore path: ${final_thin_path} to ${VM_NAME}..."
      govc vm.disk.attach -vm "${VM_NAME}" -disk "${final_thin_path}" -link=false
      
      sleep 10
      disk_index=$((disk_index + 1))
    done

    echo "Powering on ${VM_NAME}..."
    govc vm.power -on "${VM_NAME}" || true
    echo ""
}

# =========================================================================
# Verify
# =========================================================================
verify_vm() {
    echo ""       
    echo "===> Checking VM [ ${VM_NAME} ] ..."
    sleep 10
    POWER_STATE=$(govc vm.info -json "${VM_NAME}" | grep -o '"PowerState": *"[^"]*"' | head -n 1 | cut -d'"' -f4)
    if [ -z "${POWER_STATE}" ] || [ "${POWER_STATE}" = "Unknown" ]; then
      # Alternate fallback verification via raw text layout query
      POWER_STATE=$(govc vm.info "${VM_NAME}" | grep "Power state:" | awk '{print $3}')
    fi

    echo "VM Operational Profile State reported as: [ ${POWER_STATE} ]"
    if [ "${POWER_STATE}" = "poweredOn" ] || [ "${POWER_STATE}" = "poweredon" ]; then
      echo "========================================================================"
      echo " SUCCESS: VMware Virtual Machine [ ${VM_NAME} ] is safely UP and Running!"
      echo "========================================================================"
      govc vm.info -r "${VM_NAME}"
      govc vm.info -r "${VM_NAME}" >> "$METADATA_FILE"
      echo "Migration End : $(date)" >> "$METADATA_FILE"
      echo "Migration End : $(date)"
    else
      echo "ERROR: VM runtime compilation check failed. Current state is: ${POWER_STATE}"
      exit 1
    fi
}

echo "========================================="
echo " Starting End-to-End VM Migration "
echo "========================================="

# Execute Functional Pipeline
LOG_FILE="$EXPORT_DIR/${VM_NAME}-output.log"
echo "Start Date: " $(date) | tee "$LOG_FILE"
discover_vm || exit 1
stop_vm || exit 1
export_vm || exit 1
download || exit 1
unpack_vm || exit 1

#if [ "${IP_MODE}" = "DHCP" ]; then
#  assign_ip_dhcp || exit 1
#else
#  assign_ip_static || exit 1
#fi

convert_vmdk || exit 1
upload || exit 1
provision_vm || exit 1
verify_vm || exit 1
echo "End Date: " $(date) | tee "$LOG_FILE"

echo "========================================="
echo " Migration pipeline finished with SUCCESS "
echo "========================================="